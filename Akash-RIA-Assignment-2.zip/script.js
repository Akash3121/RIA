var x;

do {
  x = prompt("Enter a valid number (between 10 and 300): ");
} while (isNaN(x) || x < 10 || x > 300);

if (x >= 10 && x <= 300) {
  document.write('<table>');
  document.write('<caption><b>Pythogrean Triplets<b></caption>');
  document.write('<thead>');
  document.write('<tr>');
  document.write('<th>A</th>');
  document.write('<th>B</th>');
  document.write('<th>C</th>');
  document.write('</tr>');
  document.write('</thead>');
  var a = document.getElementById("answer");
  for (var i = 0; i < x; i++)

    for (var j = i + 1; j < x; j++)

      for (var k = j + 1; k < x; k++)
        if (i * i + j * j == k * k) {
          document.write('<tr>');
          document.write('<td>' + i + '</td>');
          document.write('<td>' + j + '</td>');
          document.write('<td>' + k + '</td>');
          document.write('</tr>');
        }

  document.write('</table>');
}
else {
  alert("Invalid number")
  document.write("Please try again!")
}