// let username;
// let zipCode;
// $("#addZipBt").click(() => {
//   if ($("#user_name").val() == "") {
//     alert("username is empty");
//   } else {
//     username = $("#user_name").val();
//   }
//   $("#postSubmit").click(() => {
//     if ($("#zipCode").val() == "") {
//       alert("zipCode is empty");
//     } else {
//       zipCode = $("#zipCode").val();
//     }
//     let out = { username: username, zipcode: zipCode };
//     // $.post("/item/", out);
//   });
// });

