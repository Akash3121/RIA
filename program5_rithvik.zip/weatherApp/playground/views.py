from django.shortcuts import render
from django.views import View
from django.http import JsonResponse
from playground.models import myZip, MyUser
import json

# Create your views here.


def hello(request):
    return render(request, 'home.html')


class Item(View):
    def post(self, request):
        a = MyUser.objects.filter(data=request.POST["zipCode"])
        if len(a) == 0:
            o = MyUser(data=request.POST["zipCode"])
            o.save()
        else:
            o = a[0]
        zip=myZip(owner=o,data=request.POST["username"])
        zip.save()
        datalist=list(myZip.objects.all().values())
        return render(request,"item.html",{"output":datalist})
    def get(self, request):
        datalist=list(myZip.objects.all().values())
        return render(request,"item.html",{"output":datalist})

