$(document).ready(() => {
  let count = 0;

  $(".submit").click(() => {
    const top = $(".top").val();
    const left = $(".left").val();
    const red = $(".red").val();
    const green = $(".green").val();
    const blue = $(".blue").val();
    const height = $(".height").val();
    const width = $(".width").val();

    // Clear previous error messages
    $(".errorMssg").remove();

    // Validation and error handling
    if (!isValidInput(top, left, red, green, blue, height, width)) {
      return; // Exit if there are validation errors
    }

    // Clear the form fields
    $('.form')[0].reset();

    // Display area settings
    $(".mainDiv").css("display", "block");

    // Increment count for unique class name
    count++;

    // Create rectangle and append to display area
    let className = `rectangle${count}`;
    $(".mainDiv").append(`<div class=${className}></div>`);
    $(`.${className}`).css({
      backgroundColor: `rgb(${red},${green},${blue})`,
      height: `${height}px`,
      width: `${width}px`,
      position: "absolute",
      top: `${top}px`,
      left: `${left}px`,
      border: `2px solid black`,
    });

    // Click event to delete the rectangle
    $(`.${className}`).click(() => {
      count--;
      $(`.${className}`).remove();
    });

    function isValidInput(top, left, red, green, blue, height, width) {
      let isValid = true;

      function handleValidation(field, errorMessage) {
        let errorSelector = `span.${field}Error`;

        if (!isValid) {
          $(errorSelector).addClass("errorMssg");
          $(errorSelector).text(errorMessage);
        }
      }

      if (parseInt(top) < 0 || top === "") {
        isValid = false;
        handleValidation("top", "**Invalid TOP input**");
      }

      if (parseInt(left) < 0 || left === "") {
        isValid = false;
        handleValidation("left", "**Invalid LEFT input**");
      }

      if (parseInt(red) < 0 || parseInt(red) > 255 || red === "") {
        isValid = false;
        handleValidation("red", "**Invalid RED input**");
      }

      if (parseInt(green) < 0 || parseInt(green) > 255 || green === "") {
        isValid = false;
        handleValidation("green", "**Invalid GREEN input**");
      }

      if (parseInt(blue) < 0 || parseInt(blue) > 255 || blue === "") {
        isValid = false;
        handleValidation("blue", "**Invalid BLUE input**");
      }

      if (parseInt(height) < 10 || parseInt(height) > 100 || height === "") {
        isValid = false;
        handleValidation("height", "**Invalid HEIGHT input**");
      }

      if (parseInt(width) < 10 || parseInt(width) > 100 || width === "") {
        isValid = false;
        handleValidation("width", "**Invalid WIDTH input**");
      }

      return isValid;
    }
  });
});
