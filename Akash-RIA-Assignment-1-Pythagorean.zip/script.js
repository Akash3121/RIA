// Prompt the user for 3 numbers
const a = prompt('Enter the first number (a):');
const b = prompt('Enter the second number (b):');
const c = prompt('Enter the third number (c):');

// Check if the numbers form a Pythagorean triple
if (!isNaN(a) && !isNaN(b) && !isNaN(c)) {
  const isPythagorean = a * a + b * b === c * c;

  // Display the result
  // const resultElement = document.createElement('h1');
  const resultElement = document.getElementById('result');
  resultElement.textContent = isPythagorean ? 'Yes!' : 'No!';
  resultElement.className = isPythagorean ? 'yes' : 'no';
  document.body.appendChild(resultElement);
} else {
  // Display error if inputs are not valid numbers
  // const errorElement = document.createElement('h1');
  const errorElement = document.getElementById('result');
  errorElement.textContent = 'Error.';
  errorElement.className = 'error';
  document.body.appendChild(errorElement);
}
