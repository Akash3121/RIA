from django.apps import AppConfig


class BricksmasherAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bricksmasher_app'
