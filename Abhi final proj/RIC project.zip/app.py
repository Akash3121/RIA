from flask import Flask, render_template, request, flash, redirect, jsonify, json
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

SECRET_KEY = 'ImagineAmDragonKing'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bricks.sqlite'
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class User(db.Model):
    """
    User Model (db table)
    """
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(255))
    lastname = db.Column(db.String(255))
    email = db.Column(db.String(255))
    checkouts = db.relationship('Checkout', backref='user', lazy=True)


class Movie(db.Model):
    """
    Movie Model (db table)
    """
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255))
    in_stock = db.Column(db.Integer)  # by default is 1
    checked_out = db.Column(db.Integer, nullable=True)
    checkouts = db.relationship('Checkout', backref='movie', lazy=True)


class Checkout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"))
    checkout_date = db.Column(db.DateTime, nullable=True)
    return_date = db.Column(db.DateTime, nullable=True)


# Creates tables for in the sqlite db
with app.app_context():
    db.create_all()


@app.route('/')
def index():
    return render_template('home.html')


@app.route('/account', methods=['POST', "GET"])
def account():
    """
    Account page
    On GET, returns the Account page html
    On POST, creates a new user
    """
    if request.method == 'GET':
        return render_template('account.html')
    if request.method == "POST":
        firstname = request.form.get('firstname')
        lastname = request.form.get('lastname')
        email = request.form.get('email')

        # Validate if fields have filled
        if not firstname or not lastname or not email:
            flash('All fields are required')
            return render_template('account.html')

        # Validate if email already exists
        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists')
            return render_template('account.html')

        # Create new user
        new_user = User(firstname=firstname, lastname=lastname, email=email)
        db.session.add(new_user)
        db.session.commit()

        # Send a notification that user has been created
        flash('Account created successfully')

        return redirect('/account')


@app.route('/movie', methods=['GET', 'POST'])
@app.route('/movie/<int:id>/<string:action>', methods=['POST'])
def movie(id=None, action=None):
    if request.method == 'GET':
        # Fetch movies and return them in alphabetical order
        movies = Movie.query.order_by(Movie.title).all()
        return render_template('movie.html', movies=movies)

    if request.method == 'POST':
        if id != None and action != None:
            if action == 'add':
                movie = Movie.query.filter_by(id=id).first()
                movie.in_stock = movie.in_stock + 1
                db.session.commit()
                flash('Movie Stock Incremented successfully')
                return redirect('/movie')
            if action == 'remove':
                movie = Movie.query.filter_by(id=id).first()
                # check if the current in-stock is 1 and if not prevent decrement
                if movie.in_stock == 1:
                    flash('Movie stock cannot be less than 1')
                    return redirect('/movie')
                movie.in_stock = movie.in_stock - 1
                db.session.commit()
                flash('Movie stock decremented successfully')
                return redirect('/movie')
        else:
            title = request.form.get('title')
            in_stock = 1
            checked_out = 0

            # Validate if fields have filled
            if not title:
                flash('Movie Title is required')
                return render_template('movie.html')

            # Validate if movie already exists
            movie = Movie.query.filter_by(title=title).first()
            if movie:
                flash('Movie already exists')
                return render_template('movie.html')

            # Create new movie
            new_movie = Movie(title=title, in_stock=in_stock,
                              checked_out=checked_out)
            db.session.add(new_movie)
            db.session.commit()

            flash('Movie added successfully')

            return redirect('/movie')


@app.route('/rent', methods=['GET', 'POST'])
@app.route('/rent/<int:userId>/<int:movieId>/<string:action>', methods=['POST'])
def rent(userId=None, movieId=None, action=None):
    movies = Movie.query.order_by(Movie.title).all()
    if request.method == 'GET':
        return render_template('rent.html', user=None, checkouts=[], movies=movies, user_movies=[])
    if request.method == 'POST':
        if userId != None and movieId != None and action != None:
            if action == 'return':
                # check if movie is in stock
                movie = Movie.query.filter_by(id=movieId).first()
                if movie.in_stock == 1:
                    flash('Movie is already in stock')
                    return redirect('/rent')
                # check if user has already checked out this movie
                checkout = Checkout.query.filter_by(
                    user_id=userId, movie_id=movieId).first()
                if not checkout:
                    flash('Movie not checked out by this user')
                    return redirect('/rent')
                # update checkout
                checkout.return_date = db.func.current_timestamp()
                db.session.commit()
                # increment movie in_stock
                movie.in_stock = movie.in_stock + 1
                # decrement checked_out
                movie.checked_out = movie.checked_out - 1
                db.session.commit()
                flash('Movie returned successfully')
                return redirect('/rent')
            if action == 'checkout':
                # check if movie is in stock
                movie = Movie.query.filter_by(id=movieId).first()
                if movie.in_stock == 0:
                    flash('Movie is out of stock')
                    return redirect('/rent')
                # check if user has already checked out this movie
                checkout = Checkout.query.filter_by(
                    user_id=userId, movie_id=movieId).first()
                if checkout:
                    flash('Movie already checked out by this user')
                    return redirect('/rent')
                # create new checkout
                checkout_date = db.func.current_timestamp()
                new_checkout = Checkout(
                    user_id=userId, movie_id=movieId, checkout_date=checkout_date)
                db.session.add(new_checkout)
                db.session.commit()
                # decrement movie in_stock
                movie.in_stock = movie.in_stock - 1
                # Increment checked_out
                movie.checked_out = movie.checked_out + 1
                db.session.commit()
                flash('Movie checked out successfully')
                return redirect('/rent')
        else:
            email = request.form.get('email')
            user = User.query.filter_by(email=email).first()
            if not user:
                flash('User not found')
                return render_template('rent.html', user=None, checkouts=[], movies=movies, user_movies=[])

            checkouts = Checkout.query.filter_by(user_id=user.id).all()
            # getting movies that belong to this user
            user_movies = []
            for checkout in checkouts:
                # get the movie which doesnt have a return date
                movie = Movie.query.filter_by(id=checkout.movie_id).first()
                print(movie)
                try:
                    if movie.return_date:
                        continue
                except:
                    user_movies.append(movie)
            return render_template('rent.html', user=user, checkouts=checkouts, movies=movies, user_movies=user_movies)


'''
    API Endpoints
'''


@app.route('/dbUser', methods=['POST'])
@app.route('/dbUser/<string:email>', methods=['GET'])
def dbUser(email: None):
    '''
        GET: Get user by email
        POST: Create new user
    '''
    if request.method == "GET":
        user = User.query.filter_by(email=email).first()
        if not user:
            return "User not found", 404

        return jsonify(user.serialize()), 200

    if request.method == "POST":
        data = json.loads(request.data)
        data = dict(data)
        firstname = data.get('firstname')
        lastname = data.get('lastname')
        email = data.get('email')

        # Validate if fields have filled
        if not firstname or not lastname or not email:
            return "All fields are required", 400

        # Validate if user already exists
        user = User.query.filter_by(email=email).first()
        if user:
            return "User already exists", 400

        # Create new user
        new_user = User(firstname=firstname, lastname=lastname, email=email)
        db.session.add(new_user)
        db.session.commit()

        return jsonify(new_user.serialize()), 201


@app.route('/dbMovie', methods=['GET'])
@app.route('/dbMovie/<string:action>/<int:id>', methods=['POST'])
def dbMovie(action=None, id=None):
    '''
        GET: Get all movies
        POST: Create new movie
        POST: Increment Stock
        POST: Decrement Stock
    '''
    if request.method == "GET":
        movies = Movie.query.order_by(Movie.title).all()
        return jsonify([movie.serialize() for movie in movies]), 200

    if request.method == "POST":
        if action == "new":
            data = json.loads(request.data)
            data = dict(data)

            title = data.get('title')

            in_stock = 1
            checked_out = 0

            # Validate if fields have filled
            if not title:
                return "Movie Title is required", 400

            # Validate if movie already exists
            movie = Movie.query.filter_by(title=title).first()
            if movie:
                return "Movie already exists", 400

            # Create new movie
            new_movie = Movie(title=title, in_stock=in_stock,
                              checked_out=checked_out)
            db.session.add(new_movie)
            db.session.commit()

            # return all movie objects

            movies = Movie.query.order_by(Movie.title).all()
            return jsonify([movie.serialize() for movie in movies]), 201
        elif action == "add":
            movie = Movie.query.filter_by(id=id).first()
            if not movie:
                return "Movie not found", 404

            movie.in_stock = movie.in_stock + 1
            db.session.commit()

            # return all movie objects

            movies = Movie.query.order_by(Movie.title).all()
            return jsonify([movie.serialize() for movie in movies]), 200

        elif action == "remove":
            movie = Movie.query.filter_by(id=id).first()
            if not movie:
                return "Movie not found", 404

            if movie.in_stock == 0:
                return "Movie out of stock", 400

            movie.in_stock = movie.in_stock - 1
            db.session.commit()

            # return all movie objects

            movies = Movie.query.order_by(Movie.title).all()
            return jsonify([movie.serialize() for movie in movies]), 200


@app.route('/dbRent', methods=['GET'])
@app.route('/dbRent/<int:userId>/<int:movieId>', methods=['GET'])
@app.route('/dbRent/<string:action>/<int:userId>/<int:movieId>', methods=['POST'])
def dbRent(action=None, userId=None, movieId=None):
    '''
        GET: Get all checkouts
        GET: Get checkouts by user
        POST: Checkout movie
        POST: Return movie
    '''
    if request.method == "GET":
        if userId and movieId:
            checkout = Checkout.query.filter_by(
                user_id=userId, movie_id=movieId).first()
            if not checkout:
                return "Checkout not found", 404

            return jsonify(checkout.serialize()), 200

        if userId and movieId == None:
            checkouts = Checkout.query.filter_by(user_id=userId).all()
            return jsonify([checkout.serialize() for checkout in checkouts]), 200

        if movieId and userId == None:
            checkouts = Checkout.query.filter_by(movie_id=movieId).all()
            return jsonify([checkout.serialize() for checkout in checkouts]), 200

        checkouts = Checkout.query.order_by(Checkout.checkout_date).all()
        return jsonify([checkout.serialize() for checkout in checkouts]), 200

    if request.method == "POST":
        if action == "rent":
            # check if movie is in stock
            movie = Movie.query.filter_by(id=movieId).first()
            if movie.in_stock == 0:
                return "Movie is out of stock", 400
            # check if user has already checked out this movie
            checkout = Checkout.query.filter_by(
                user_id=userId, movie_id=movieId).first()
            if checkout:
                return "Movie already checked out by this user", 400
            # create new checkout
            checkout_date = db.func.current_timestamp()
            new_checkout = Checkout(
                user_id=userId, movie_id=movieId, checkout_date=checkout_date)
            db.session.add(new_checkout)
            db.session.commit()
            # decrement movie in_stock
            movie.in_stock = movie.in_stock - 1
            # Increment checked_out
            movie.checked_out = movie.checked_out + 1
            db.session.commit()

            # return all checkout objects

            checkouts = Checkout.query.order_by(
                Checkout.checkout_date).all()
            return jsonify([checkout.serialize() for checkout in checkouts]), 201

        elif action == "return":
            # check if checkout exists
            checkout = Checkout.query.filter_by(
                user_id=userId, movie_id=movieId).first()
            if not checkout:
                return "Checkout not found", 404
            # check if movie has already been returned
            movie = Movie.query.filter_by(id=movieId).first()
            try:
                if movie.return_date:
                    return "Movie already returned", 400
            except:
                pass
            # update checkout
            return_date = db.func.current_timestamp()
            checkout.return_date = return_date
            db.session.commit()

            # increment movie in_stock
            movie.in_stock = movie.in_stock + 1
            # decrement checked_out
            movie.checked_out = movie.checked_out - 1

            db.session.commit()

            # return all checkout objects
            checkouts = Checkout.query.order_by(
                Checkout.checkout_date).all()
            return jsonify([checkout.serialize() for checkout in checkouts]), 200


if __name__ == '__main__':
    app.run(debug=True)
