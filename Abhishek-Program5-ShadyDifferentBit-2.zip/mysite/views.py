import requests
from django.http import JsonResponse
from django.views import View
from .models import ZipCode


class ZipCodeView(View):
    def get(self, request):
        username = request.GET.get('username', '')
        zip_codes = ZipCode.objects.filter(
            user__username=username).values_list('zip_code', flat=True)
        response_data = []
        for zip_code in zip_codes:
            weather_data = self.get_weather_data(zip_code)
            if weather_data:
                response_data.append({
                    'zip_code': zip_code,
                    'temp_f': weather_data['main']['temp']
                })
        return JsonResponse({'success': True, 'data': response_data})

    def post(self, request):
        username = request.POST.get('username', '')
        zip_code = request.POST.get('zip_code', '')
        if not zip_code.isdigit() or len(zip_code) != 5:
            return JsonResponse({
                'success': False,
                'error': 'Invalid zip code'
            })
        if ZipCode.objects.filter(user__username=username,
                                  zip_code=zip_code).exists():
            return JsonResponse({
                'success': False,
                'error': 'Zip code already added'
            })
        zip_code_obj = ZipCode(user=request.user, zip_code=zip_code)
        zip_code_obj.save()
        return JsonResponse({'success': True})

    def get_weather_data(self, zip_code):
        url = f'https://api.openweathermap.org/data/2.5/weather?zip={zip_code}&appid=348183c2bcde647082aac8dbabbc3019&units=imperial'
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        return None
