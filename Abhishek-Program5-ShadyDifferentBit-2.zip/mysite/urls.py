from django.urls import path
from .views import index

urlpatterns = [
    path('', views.index, name='index'),
    path('api/zipcodes', views.zipcodes_api, name='zipcodes_api'),
    path('add_zipcode', views.add_zipcode, name='add_zipcode'),
]