function addZipCode() {
  const username = document.getElementById('username').value;
  const zipCode = document.getElementById('zip-code').value;
  const url = '/api/zipcodes';

  fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: username, zip: zipCode })
  })
    .then(response => response.json())
    .then(result => {
      if (result.success) {
        alert(`Zip code ${zipCode} added successfully.`);
      } else {
        alert(result.error);
      }
    })
    .catch(error => console.error(error));
}

document.getElementById('add-zip-code-form').addEventListener('submit', event => {
  event.preventDefault();
  addZipCode();
});
