function getZipCodes() {
  const username = document.getElementById('username').value;
  const url = `/api/zipcodes?username=${username}`;

  fetch(url)
    .then(response => response.json())
    .then(result => {
      if (result.success) {
        updateTable(result.data);
      } else {
        console.error(result.error);
      }
    })
    .catch(error => console.error(error));
}

function updateTable(zipCodes) {
  const url = 'https://api.openweathermap.org/data/2.5/weather';
  const apiKey = '348183c2bcde647082aac8dbabbc3019';
  const tableBody = document.getElementById('zip-code-table-body');

  tableBody.innerHTML = '';

  zipCodes.forEach(zipCode => {
    const params = `?zip=${zipCode}&units=imperial&appid=${apiKey}`;
    const row = document.createElement('tr');
    const zipCodeCell = document.createElement('td');
    const tempCell = document.createElement('td');

    fetch(url + params)
      .then(response => response.json())
      .then(result => {
        zipCodeCell.textContent = zipCode;
        tempCell.textContent = result.main.temp + ' °F';

        row.appendChild(zipCodeCell);
        row.appendChild(tempCell);
        tableBody.appendChild(row);
      })
      .catch(error => console.error(error));
  });
}

setInterval(getZipCodes, 30000);
