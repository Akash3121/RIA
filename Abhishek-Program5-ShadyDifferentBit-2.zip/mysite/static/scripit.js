const zipCodesTable = document.getElementById("zip-codes-table");
const usernameInput = document.getElementById("username");

// Function to generate the rows for the zip codes table
function generateTableRows(zipCodes) {
    const rows = zipCodes.map(zipCode => {
        const row = document.createElement("tr");
        const zipCodeCell = document.createElement("td");
        const temperatureCell = document.createElement("td");
        zipCodeCell.textContent = zipCode;
        temperatureCell.setAttribute("data-zip-code", zipCode);
        temperatureCell.textContent = "Loading...";
        row.appendChild(zipCodeCell);
        row.appendChild(temperatureCell);
        return row;
    });
    return rows;
}

// Function to update the temperature of a zip code in the table
function updateTemperature(zipCode, temperature) {
    const temperatureCell = document.querySelector(`[data-zip-code="${zipCode}"]`);
    temperatureCell.textContent = temperature.toFixed(1);
}

// Function to fetch the zip codes for a user from the data-store and update the table
async function fetchZipCodes() {
    const username = usernameInput.value;
    const response = await fetch(`/api/zip-codes/?user=${username}`);
    const zipCodes = await response.json();
    const rows = generateTableRows(zipCodes);
    zipCodesTable.querySelector("tbody").innerHTML = "";
    rows.forEach(row => {
        zipCodesTable.querySelector("tbody").appendChild(row);
        const zipCode = row.firstChild.textContent;
        fetch(`https://api.openweathermap.org/data/2.5/weather?zip=${zipCode},us&appid={348183c2bcde647082aac8dbabbc3019}&units=imperial`)
            .then(response => response.json())
            .then(data => {
                const temperature = data.main.temp;
                updateTemperature(zipCode, temperature);
            })
            .catch(error => {
                console.log(error);
                updateTemperature(zipCode, "N/A");
            });
    });
}

// Event listener for changes to the username input
usernameInput.addEventListener("input", fetchZipCodes);

// Initial fetch of zip codes for the default username
fetchZipCodes();
